Alfresco Share ${project.version}
======================
