function main()
{
   var calendar = {
      id : "Calendar",
      name : "Alfresco.Calendar",
      assignTo : "calendar",
      useOptions: false
   };
   model.widgets = [calendar];
}

main();
